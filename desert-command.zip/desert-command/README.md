# Desert Command

`Desert Command` is a small local Android WebView RTS prototype with desert
maps, spice harvesting, fog of war, clan enemies, unit upgrades, mission
progress, and simple synthetic audio.

The game code lives in:

```text
app/src/main/assets/www/index.html
```

This is an original prototype inspired by classic desert strategy mechanics.
It does not contain copied game assets, names, music, or sprites from any
commercial game.
