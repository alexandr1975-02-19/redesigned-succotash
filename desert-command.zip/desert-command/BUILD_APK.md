# Build APK

This project wraps a local HTML RTS prototype in an Android WebView.

Requirements:

- Android Studio or Android SDK
- JDK 17

Build debug APK:

```bash
./gradlew assembleDebug
```

Output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

If there is no Gradle wrapper yet, open this folder in Android Studio once,
let it sync, then use **Build > Build APK(s)**. Android Studio can also create
the Gradle wrapper for the project.
