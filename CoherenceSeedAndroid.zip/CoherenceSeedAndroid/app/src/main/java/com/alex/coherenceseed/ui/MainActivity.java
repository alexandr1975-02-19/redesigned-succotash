package com.alex.coherenceseed.ui;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.alex.coherenceseed.R;
import com.alex.coherenceseed.service.CoherenceService;

public class MainActivity extends AppCompatActivity {

    private TextView status;
    private TextView state;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!CoherenceService.ACTION_UPDATE.equals(intent.getAction())) return;

            String mode = intent.getStringExtra(CoherenceService.EXTRA_MODE);
            float temp = intent.getFloatExtra(CoherenceService.EXTRA_TEMP, 0f);
            int bat = intent.getIntExtra(CoherenceService.EXTRA_BAT, 0);
            float cpu = intent.getFloatExtra(CoherenceService.EXTRA_CPU, 0f);
            boolean net = intent.getBooleanExtra(CoherenceService.EXTRA_NET, false);

            status.setText("Status: running · " + mode);
            state.setText(
                    "Battery: " + bat + "%\n" +
                    "Temp: " + String.format("%.1f", temp) + "°C\n" +
                    "CPU load: " + String.format("%.2f", cpu) + "\n" +
                    "Network: " + (net ? "active" : "off") + "\n\n" +
                    "Tip: grant 'Modify system settings' to allow brightness control."
            );
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        state = findViewById(R.id.state);

        Button start = findViewById(R.id.btnStart);
        Button stop = findViewById(R.id.btnStop);

        start.setOnClickListener(v -> {
            maybeRequestWriteSettings();
            Intent i = new Intent(this, CoherenceService.class);
            i.setAction(CoherenceService.ACTION_START);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(i);
            } else {
                startService(i);
            }
            status.setText("Status: starting...");
        });

        stop.setOnClickListener(v -> {
            Intent i = new Intent(this, CoherenceService.class);
            i.setAction(CoherenceService.ACTION_STOP);
            startService(i);
            status.setText("Status: stopped");
            state.setText("—");
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(receiver, new IntentFilter(CoherenceService.ACTION_UPDATE));
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(receiver);
    }

    private void maybeRequestWriteSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.System.canWrite(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
        }
    }
}
