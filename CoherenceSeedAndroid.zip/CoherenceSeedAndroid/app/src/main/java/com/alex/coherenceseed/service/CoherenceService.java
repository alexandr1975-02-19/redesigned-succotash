package com.alex.coherenceseed.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Network;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.alex.coherenceseed.core.ConstraintCore;
import com.alex.coherenceseed.core.Invariants;
import com.alex.coherenceseed.core.StateVector;
import com.alex.coherenceseed.core.SystemMode;
import com.alex.coherenceseed.control.ModeAdapter;
import com.alex.coherenceseed.ui.MainActivity;
import com.alex.coherenceseed.util.CpuLoadReader;

public class CoherenceService extends Service {

    public static final String ACTION_START = "com.alex.coherenceseed.ACTION_START";
    public static final String ACTION_STOP = "com.alex.coherenceseed.ACTION_STOP";
    public static final String ACTION_UPDATE = "com.alex.coherenceseed.ACTION_UPDATE";

    public static final String EXTRA_MODE = "mode";
    public static final String EXTRA_TEMP = "tempC";
    public static final String EXTRA_BAT = "batPct";
    public static final String EXTRA_CPU = "cpu01";
    public static final String EXTRA_NET = "net";

    private static final String CH_ID = "coherence_seed";
    private static final int NOTIF_ID = 1001;

    private HandlerThread workerThread;
    private Handler worker;

    private final ConstraintCore core = new ConstraintCore();
    private CpuLoadReader cpuReader;
    private ModeAdapter modeAdapter;

    private StateVector prevState;
    private SystemMode lastMode = SystemMode.STABLE;

    @Override
    public void onCreate() {
        super.onCreate();
        cpuReader = new CpuLoadReader();
        modeAdapter = new ModeAdapter(getApplicationContext());
        ensureChannel();
        workerThread = new HandlerThread("coherence_seed_worker");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_STOP.equals(action)) {
                stopSelf();
                return START_NOT_STICKY;
            }
        }

        startForeground(NOTIF_ID, buildForegroundNotification("Running"));

        if (prevState == null) {
            prevState = readState();
        }

        worker.removeCallbacksAndMessages(null);
        worker.post(loop);

        return START_STICKY;
    }

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            StateVector current = readState();
            SystemMode mode = core.evaluate(prevState, current);

            // Apply only when mode changes or when in alert modes
            if (mode != lastMode || mode != SystemMode.STABLE) {
                modeAdapter.apply(mode);
                lastMode = mode;
                updateForegroundNotification(mode, current);
            }

            broadcastUpdate(mode, current);

            long next = (mode == SystemMode.STABLE) ? Invariants.SAMPLE_STABLE_MS : Invariants.SAMPLE_ALERT_MS;
            prevState = current;
            worker.postDelayed(this, next);
        }
    };

    private void broadcastUpdate(SystemMode mode, StateVector s) {
        Intent i = new Intent(ACTION_UPDATE);
        i.putExtra(EXTRA_MODE, mode.name());
        i.putExtra(EXTRA_TEMP, s.batteryTempC);
        i.putExtra(EXTRA_BAT, s.batteryLevelPct);
        i.putExtra(EXTRA_CPU, s.cpuLoad01);
        i.putExtra(EXTRA_NET, s.networkActive);
        sendBroadcast(i);
    }

    private void updateForegroundNotification(SystemMode mode, StateVector s) {
        Notification n = buildForegroundNotification("Mode: " + mode.name() + " · T=" + String.format("%.1f", s.batteryTempC) + "°C");
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(NOTIF_ID, n);
    }

    private Notification buildForegroundNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CH_ID)
                .setSmallIcon(android.R.drawable.star_big_on)
                .setContentTitle("CoherenceSeed")
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private StateVector readState() {
        float tempC = readBatteryTempC();
        int batPct = readBatteryPct();
        boolean screenOn = isScreenOn();
        float cpu01 = cpuReader.readCpuLoad01();
        boolean net = isNetworkActive();
        long ts = System.currentTimeMillis();
        return new StateVector(tempC, batPct, screenOn, cpu01, net, ts);
    }

    private float readBatteryTempC() {
        try {
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = registerReceiver(null, ifilter);
            if (batteryStatus == null) return 0f;
            int tempTenths = batteryStatus.getIntExtra("temperature", 0); // tenths of a degree C
            return tempTenths / 10.0f;
        } catch (Throwable t) {
            return 0f;
        }
    }

    private int readBatteryPct() {
        try {
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = registerReceiver(null, ifilter);
            if (batteryStatus == null) return 0;
            int level = batteryStatus.getIntExtra("level", 0);
            int scale = batteryStatus.getIntExtra("scale", 100);
            if (scale <= 0) return 0;
            return Math.round((level * 100f) / scale);
        } catch (Throwable t) {
            return 0;
        }
    }

    private boolean isScreenOn() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            return pm != null && pm.isInteractive();
        } catch (Throwable t) {
            return true;
        }
    }

    private boolean isNetworkActive() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network network = cm.getActiveNetwork();
            if (network == null) return false;
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            return caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) || caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI));
        } catch (Throwable t) {
            return false;
        }
    }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CH_ID, "CoherenceSeed", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (worker != null) worker.removeCallbacksAndMessages(null);
        if (workerThread != null) workerThread.quitSafely();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
