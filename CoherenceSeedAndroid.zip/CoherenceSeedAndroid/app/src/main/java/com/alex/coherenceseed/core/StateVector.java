package com.alex.coherenceseed.core;

public class StateVector {
    public final float batteryTempC;
    public final int batteryLevelPct;
    public final boolean screenOn;
    public final float cpuLoad01;
    public final boolean networkActive;
    public final long timestampMs;

    public StateVector(float batteryTempC, int batteryLevelPct, boolean screenOn, float cpuLoad01, boolean networkActive, long timestampMs) {
        this.batteryTempC = batteryTempC;
        this.batteryLevelPct = batteryLevelPct;
        this.screenOn = screenOn;
        this.cpuLoad01 = cpuLoad01;
        this.networkActive = networkActive;
        this.timestampMs = timestampMs;
    }
}
