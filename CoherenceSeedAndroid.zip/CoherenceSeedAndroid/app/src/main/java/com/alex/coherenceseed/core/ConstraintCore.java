package com.alex.coherenceseed.core;

public class ConstraintCore {

    public SystemMode evaluate(StateVector previous, StateVector current) {
        float tempDelta = current.batteryTempC - previous.batteryTempC;

        if (current.batteryLevelPct < Invariants.MIN_BATTERY_PCT) {
            return SystemMode.POWER_SAVE;
        }

        if (current.batteryTempC > Invariants.MAX_BATTERY_TEMP_C) {
            return SystemMode.COOL_DOWN;
        }

        if (tempDelta > Invariants.MAX_TEMP_RISE_PER_SAMPLE_C) {
            return SystemMode.SMOOTH_LIMIT;
        }

        return SystemMode.STABLE;
    }
}
