package com.alex.coherenceseed.core;

public enum SystemMode {
    STABLE,
    SMOOTH_LIMIT,
    COOL_DOWN,
    POWER_SAVE
}
