package com.alex.coherenceseed.core;

public final class Invariants {
    // Conservative defaults. You can tune later.
    public static final float MAX_BATTERY_TEMP_C = 40.0f;
    public static final float MAX_TEMP_RISE_PER_SAMPLE_C = 0.4f;
    public static final int MIN_BATTERY_PCT = 15;

    // Sampling (ms)
    public static final long SAMPLE_STABLE_MS = 5000;
    public static final long SAMPLE_ALERT_MS = 1000;

    private Invariants() {}
}
