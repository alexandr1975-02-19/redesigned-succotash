package com.alex.coherenceseed.control;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.provider.Settings;

import androidx.core.app.NotificationCompat;

import com.alex.coherenceseed.R;

public class SystemActions {

    private static final String CH_ID = "coherence_seed_hints";
    private static final int NOTIF_ID = 2001;

    private final Context appContext;
    private final NotificationManager nm;

    public SystemActions(Context context) {
        this.appContext = context.getApplicationContext();
        this.nm = (NotificationManager) appContext.getSystemService(Context.NOTIFICATION_SERVICE);
        ensureChannel();
    }

    public void tryLowerBrightness() {
        setBrightness(60); // 0..255
    }

    public void trySlightLowerBrightness() {
        setBrightness(90);
    }

    private void setBrightness(int value) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.System.canWrite(appContext)) {
                    // User must grant "Modify system settings" in App settings.
                    return;
                }
            }
            Settings.System.putInt(appContext.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, clamp(value, 5, 255));
        } catch (Throwable ignored) {
        }
    }

    public void postHintNotification(String msg) {
        Notification n = new NotificationCompat.Builder(appContext, CH_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("CoherenceSeed")
                .setContentText(msg)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setAutoCancel(true)
                .build();
        nm.notify(NOTIF_ID, n);
    }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CH_ID, "CoherenceSeed Hints", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
    }

    private int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}
