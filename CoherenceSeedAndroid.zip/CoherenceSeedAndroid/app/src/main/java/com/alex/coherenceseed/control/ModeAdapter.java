package com.alex.coherenceseed.control;

import android.content.Context;

import com.alex.coherenceseed.core.SystemMode;

/**
 * Applies gentle, non-root system actions.
 * Goal: smooth stabilization, not aggressive optimization.
 */
public class ModeAdapter {

    private final SystemActions actions;

    public ModeAdapter(Context context) {
        this.actions = new SystemActions(context);
    }

    public void apply(SystemMode mode) {
        switch (mode) {
            case COOL_DOWN:
                actions.tryLowerBrightness();
                actions.postHintNotification("Cooling down: lowered brightness (if allowed).");
                break;
            case SMOOTH_LIMIT:
                actions.trySlightLowerBrightness();
                break;
            case POWER_SAVE:
                actions.postHintNotification("Low battery: consider enabling Battery Saver.");
                break;
            case STABLE:
            default:
                // do nothing
                break;
        }
    }
}
