package com.alex.coherenceseed.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Light-weight CPU load estimate (0..1) from /proc/stat.
 * Works without root on most devices.
 */
public class CpuLoadReader {

    private long prevIdle = -1;
    private long prevTotal = -1;

    public float readCpuLoad01() {
        try (BufferedReader br = new BufferedReader(new FileReader("/proc/stat"))) {
            String line = br.readLine();
            if (line == null || !line.startsWith("cpu ")) {
                return 0f;
            }
            String[] toks = line.trim().split("\\s+");
            // cpu user nice system idle iowait irq softirq steal guest guest_nice
            long user = parseLongSafe(toks, 1);
            long nice = parseLongSafe(toks, 2);
            long system = parseLongSafe(toks, 3);
            long idle = parseLongSafe(toks, 4);
            long iowait = parseLongSafe(toks, 5);
            long irq = parseLongSafe(toks, 6);
            long softirq = parseLongSafe(toks, 7);
            long steal = parseLongSafe(toks, 8);

            long idleAll = idle + iowait;
            long nonIdle = user + nice + system + irq + softirq + steal;
            long total = idleAll + nonIdle;

            if (prevTotal < 0) {
                prevTotal = total;
                prevIdle = idleAll;
                return 0f;
            }

            long totald = total - prevTotal;
            long idled = idleAll - prevIdle;

            prevTotal = total;
            prevIdle = idleAll;

            if (totald <= 0) return 0f;

            float load = (float) (totald - idled) / (float) totald;
            if (load < 0f) load = 0f;
            if (load > 1f) load = 1f;
            return load;
        } catch (IOException e) {
            return 0f;
        }
    }

    private long parseLongSafe(String[] toks, int idx) {
        if (idx >= toks.length) return 0L;
        try {
            return Long.parseLong(toks[idx]);
        } catch (NumberFormatException e) {
            return 0L;
        }
    }
}
