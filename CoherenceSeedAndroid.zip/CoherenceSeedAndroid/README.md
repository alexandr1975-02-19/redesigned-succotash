# CoherenceSeed (Samsung A14) — Java prototype

This is a minimal Android Studio project that implements the "Constraint Core" idea:
- reads device state (battery temp/level, screen, CPU load, network)
- evaluates a stable mode via `ConstraintCore`
- runs as a foreground service and broadcasts updates to the UI
- applies gentle non-root actions (brightness adjustment) if the user grants permission

## How to build an APK (Android Studio)
1. Open **Android Studio** → **Open** → select the `CoherenceSeedAndroid` folder.
2. Let Gradle sync (Android Studio will download required components).
3. Connect your Samsung Galaxy A14 with USB debugging enabled.
4. Click **Run** (green triangle) to install and run.

## Permissions
- The app will ask for **Modify system settings** so it can lower brightness in COOL_DOWN mode.
- Without it, the app still runs and shows the detected state/mode.

## Notes
- This is a "seed": no aggressive task killing, no root controls.
- Next steps: add hysteresis, multi-parameter constraints, user-defined comfort presets.
